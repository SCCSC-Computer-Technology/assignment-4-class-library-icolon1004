﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using US_States.StatesDataSetTableAdapters;

namespace US_States
{
    internal class ClassLibrary
    {
        //Creating instance of 
        private readonly US_StatesTableAdapter uS_StatesTableAdapter;
        private readonly StatesDataSet statesDataSet;
                

        //Fills Combo box with states
        private void LoadStatesIntoComboBox(ComboBox stateComboBox)
        {
            var result = from state in statesDataSet.US_States
                         select state.State_Name;

            stateComboBox.Items.AddRange(result.ToArray());
        }

        //Method to search state data from chosen item
        private void SelectDropdownState(StatesClass state, ComboBox stateComboBox)
        {
            //State chosen from dropdown stored into variable
            state.StateName = stateComboBox.SelectedItem.ToString();

            //SQL query
            this.uS_StatesTableAdapter.SelectState(this.statesDataSet.US_States, state.StateName);


            state.State = stateComboBox.SelectedItem.ToString();

            //Allows to call state details into another form
            var stateDetails = new StatesClass
            {
                State = state.State
            };


        }

        //Method to filter data upon user input running queries
        //Overloaded method with radiobutton options
        private void FilterData(StatesClass state, TextBox stateValueTextBox, RadioButton flagDescriptionRadioButton, RadioButton stateNameRadioButton, RadioButton stateFlowerRadioButton, RadioButton stateBirdRadioButton, RadioButton stateColorsRadioButton, RadioButton threeLargestCitiesRadioButton, RadioButton stateCapitolRadioButton)
        {
            state.StateName = stateValueTextBox.Text;


            if (flagDescriptionRadioButton.Checked)
            {
                this.uS_StatesTableAdapter.SelectFlagDescription(this.statesDataSet.US_States, state.StateName);
            }
            else if (stateNameRadioButton.Checked)
            {
                this.uS_StatesTableAdapter.SelectState(this.statesDataSet.US_States, state.StateName);
            }
            else if (stateFlowerRadioButton.Checked)
            {
                this.uS_StatesTableAdapter.SelectStateFlower(this.statesDataSet.US_States, state.StateName);
            }
            else if (stateBirdRadioButton.Checked)
            {
                this.uS_StatesTableAdapter.selectStateBird(this.statesDataSet.US_States, state.StateName);
            }
            else if (stateColorsRadioButton.Checked)
            {
                this.uS_StatesTableAdapter.SelectStateColors(this.statesDataSet.US_States, state.StateName);
            }
            else if (threeLargestCitiesRadioButton.Checked)
            {
                this.uS_StatesTableAdapter.SelectThreeLargestCities(this.statesDataSet.US_States, state.StateName);
            }
            else if (stateCapitolRadioButton.Checked)
            {
                this.uS_StatesTableAdapter.SelectStateCapitol(this.statesDataSet.US_States, state.StateName);
            }
        }

        //Method to filter numeric data upon user input running queries
        //Overloaded method with radiobutton options
        private void FilterNumericData(StatesClass state, TextBox numberValueTextBox, CheckBox lessThenCheckBox, CheckBox greaterThenCheckBox, RadioButton populationRadioButton, RadioButton medianIncomeRadioButton, RadioButton percentageOfComputerJobsRadioButton)
        {
            state.StateName = numberValueTextBox.Text;

            //Filters data with queries in SQL depennding on user input
            if (lessThenCheckBox.Checked)
            {
                if (populationRadioButton.Checked)
                {
                    this.uS_StatesTableAdapter.SelectPopulationLessThen(this.statesDataSet.US_States, int.Parse(state.StateName));
                }
                else if (medianIncomeRadioButton.Checked)
                {
                    this.uS_StatesTableAdapter.SelectMedianIncomeLessThen(this.statesDataSet.US_States, int.Parse(state.StateName));
                }
                else if (percentageOfComputerJobsRadioButton.Checked)
                {
                    this.uS_StatesTableAdapter.SelectPercentageLessThen(this.statesDataSet.US_States, state.StateName);
                }
            }
            if (greaterThenCheckBox.Checked)
            {
                if (populationRadioButton.Checked)
                {
                    this.uS_StatesTableAdapter.SelectPopulationGreaterThen(this.statesDataSet.US_States, int.Parse(state.StateName));
                }
                else if (medianIncomeRadioButton.Checked)
                {
                    this.uS_StatesTableAdapter.SelectMedianIncomeGreaterThen(this.statesDataSet.US_States, int.Parse(state.StateName));
                }
                else if (percentageOfComputerJobsRadioButton.Checked)
                {
                    this.uS_StatesTableAdapter.SelectPercentageGreaterThen(this.statesDataSet.US_States, state.StateName);
                }
            }
        }

       
    }
}
